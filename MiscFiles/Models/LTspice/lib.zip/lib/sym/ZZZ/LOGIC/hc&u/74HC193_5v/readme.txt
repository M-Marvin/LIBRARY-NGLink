readme.txt

Usage:
Use the 74hc193.asy assembly file in your circuit designs along with a .param statement as discribed below

Each gate has a tdgate, and D flip flop has a tdgate2, time delay (td) in value2 line.
Each gate and flip flop has a vhighgate voltage value for logic high.
Each gate and flip flop has a vlowgate voltage value for logic low.
One way to assign these values is through a .param statement in main circuit (74hc193_test.asc for example).

74hc193.asc component requires:TnotSRFlipFlopfromD.asc and TnotSRFlipFlopfromD.asy files to work.

Copyright:  
No rights reserved, no liability covered, no warranty of use given or implied, no indemnity offered, support optional.
Ron Fredericks, Embedded Components, Inc.
www.embeddedcomponents.com/blogs/
April 21, 2008

